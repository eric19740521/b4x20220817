package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4a.net.SMTPWrapper _smtp = null;
public static b4j.example.b4xloadingindicator _indloading = null;
public static b4j.example.dateutils _dateutils = null;
public static b4j.example.cssutils _cssutils = null;
public static b4j.example.xuiviewsutils _xuiviewsutils = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 17;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 18;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 19;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 21;BA.debugLine="indLoading.Hide";
_indloading._hide /*String*/ ();
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public static void  _button1_click() throws Exception{
ResumableSub_Button1_Click rsub = new ResumableSub_Button1_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button1_Click extends BA.ResumableSub {
public ResumableSub_Button1_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
anywheresoftware.b4a.objects.collections.Map _m = null;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 31;BA.debugLine="SMTP.Initialize(\"smtp.porkbun.com\",587,\"eric19740";
parent._smtp.Initialize("smtp.porkbun.com",(int) (587),"eric19740521@b234.top","ho661728","SMTP");
 //BA.debugLineNum = 33;BA.debugLine="Dim M As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 34;BA.debugLine="M.Initialize";
_m.Initialize();
 //BA.debugLineNum = 35;BA.debugLine="M.Put(\"Content-Type\", \"text/html; charset=utf-8\")";
_m.Put((Object)("Content-Type"),(Object)("text/html; charset=utf-8"));
 //BA.debugLineNum = 36;BA.debugLine="M.Put(\"Content-Transfer-Encoding\", \"7bit\")";
_m.Put((Object)("Content-Transfer-Encoding"),(Object)("7bit"));
 //BA.debugLineNum = 37;BA.debugLine="SMTP.AdditionalHeaders = M					'這個可以不用加";
parent._smtp.AdditionalHeaders = _m;
 //BA.debugLineNum = 41;BA.debugLine="SMTP.StartTLSMode = True";
parent._smtp.setStartTLSMode(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 42;BA.debugLine="SMTP.UseSSL = True";
parent._smtp.setUseSSL(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 44;BA.debugLine="SMTP.Sender = \"eric19740521@b234.top\"	'寄件人";
parent._smtp.Sender = "eric19740521@b234.top";
 //BA.debugLineNum = 45;BA.debugLine="SMTP.To.Add(\"eric19740521@gmail.com\")	'收件人";
parent._smtp.getTo().Add((Object)("eric19740521@gmail.com"));
 //BA.debugLineNum = 46;BA.debugLine="SMTP.AuthMethod = SMTP.AUTH_LOGIN";
parent._smtp.setAuthMethod(parent._smtp.AUTH_LOGIN);
 //BA.debugLineNum = 49;BA.debugLine="SMTP.HtmlBody = True";
parent._smtp.setHtmlBody(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 50;BA.debugLine="SMTP.Subject = \"test\"";
parent._smtp.setSubject("test");
 //BA.debugLineNum = 51;BA.debugLine="SMTP.Body = CreateHtmlBody '\"<h1>test測試寄信件1234</h";
parent._smtp.setBody(_createhtmlbody());
 //BA.debugLineNum = 55;BA.debugLine="LogDebug(SMTP.body)";
anywheresoftware.b4a.keywords.Common.LogDebug(parent._smtp.getBody());
 //BA.debugLineNum = 56;BA.debugLine="LogDebug(\"Sending email...\")";
anywheresoftware.b4a.keywords.Common.LogDebug("Sending email...");
 //BA.debugLineNum = 58;BA.debugLine="indLoading.show";
parent._indloading._show /*String*/ ();
 //BA.debugLineNum = 59;BA.debugLine="Wait For (SMTP.Send) SMTP_MessageSent (Success As";
anywheresoftware.b4a.keywords.Common.WaitFor("smtp_messagesent", ba, this, parent._smtp.Send(ba));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_success = (boolean) result[0];
;
 //BA.debugLineNum = 60;BA.debugLine="indLoading.Hide";
parent._indloading._hide /*String*/ ();
 //BA.debugLineNum = 61;BA.debugLine="If Success Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_success) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 62;BA.debugLine="Log(\"Message sent successfully\")";
anywheresoftware.b4a.keywords.Common.LogImpl("4131109","Message sent successfully",0);
 //BA.debugLineNum = 64;BA.debugLine="xui.MsgboxAsync(\"ok\",\"info\")";
parent._xui.MsgboxAsync(ba,"ok","info");
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 66;BA.debugLine="Log(\"Error sending message\")";
anywheresoftware.b4a.keywords.Common.LogImpl("4131113","Error sending message",0);
 //BA.debugLineNum = 67;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("4131114",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _smtp_messagesent(boolean _success) throws Exception{
}
public static String  _createhtmlbody() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _html = null;
 //BA.debugLineNum = 74;BA.debugLine="Sub CreateHtmlBody() As String";
 //BA.debugLineNum = 75;BA.debugLine="Dim HTML As StringBuilder";
_html = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 76;BA.debugLine="HTML.Initialize";
_html.Initialize();
 //BA.debugLineNum = 78;BA.debugLine="HTML.Append($\"\"$)";
_html.Append((""));
 //BA.debugLineNum = 79;BA.debugLine="HTML.Append($\"<h1>test測試寄信件1234</h1>\"$)";
_html.Append(("<h1>test測試寄信件1234</h1>"));
 //BA.debugLineNum = 82;BA.debugLine="Return HTML";
if (true) return BA.ObjectToString(_html);
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.dateutils._process_globals();
b4j.example.cssutils._process_globals();
main._process_globals();
xuiviewsutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Dim SMTP As SMTP		'JNet LIB";
_smtp = new anywheresoftware.b4a.net.SMTPWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private indLoading As B4XLoadingIndicator";
_indloading = new b4j.example.b4xloadingindicator();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
}
